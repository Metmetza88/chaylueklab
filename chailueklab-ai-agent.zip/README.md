# CHAILUEKLAB AI Agent

Backend เริ่มต้นสำหรับระบบ **CHAILUEKLAB AI Operating System**

ฟังก์ชันที่มีในเวอร์ชันนี้:

- LINE OA Webhook
- คำสั่ง `/`
- ระบบสินค้า JSON
- ระบบออเดอร์ JSON
- สรุปยอดขายวันนี้
- Dashboard API
- Health Check
- Rate Limit / Helmet / CORS
- Logging
- Railway config
- Test เบื้องต้น

## 1. ติดตั้ง Node.js

แนะนำ Node.js 20 ขึ้นไป

ตรวจสอบ:

```bash
node -v
npm -v
```

## 2. ติดตั้งแพ็กเกจ

```bash
npm install
```

## 3. สร้างไฟล์ .env

คัดลอกจาก `.env.example`

```bash
cp .env.example .env
```

จากนั้นใส่ค่าที่จำเป็น

```env
PORT=3000

AI_PROVIDER=mock
OPENAI_API_KEY=
OPENAI_MODEL=gpt-5

LINE_CHANNEL_ACCESS_TOKEN=
LINE_CHANNEL_SECRET=

ADMIN_USERS=
GROUP_COMMAND_ONLY=true
CUSTOMER_BOT_ENABLED=true
```

## 4. รัน Development

```bash
npm run dev
```

เปิด:

```text
http://localhost:3000/
http://localhost:3000/health
http://localhost:3000/api/dashboard
```

## 5. คำสั่งที่รองรับ

```text
/help
/status
/health
/สินค้า
/สต็อก
/ยอดวันนี้
/ออเดอร์ ORD-DEMO-001
```

## 6. แก้ข้อมูลสินค้า

เปิดไฟล์:

```text
data/products.json
```

เพิ่มสินค้าโดยยึดโครงสร้างเดิม

## 7. แก้ออเดอร์

เปิดไฟล์:

```text
data/orders.json
```

เวอร์ชันเริ่มต้นใช้ JSON เพื่อให้ทดสอบง่าย

ภายหลังแนะนำย้ายไป PostgreSQL หรือ Supabase

## 8. LINE OA

ต้องมี:

- LINE_CHANNEL_ACCESS_TOKEN
- LINE_CHANNEL_SECRET

ตั้ง Webhook URL เป็น:

```text
https://YOUR-DOMAIN/webhook/line
```

เปิด `Use webhook` ใน LINE Developers Console

สำหรับกลุ่ม:

```env
GROUP_COMMAND_ONLY=true
```

ระบบจะตอบเฉพาะข้อความที่ขึ้นต้นด้วย `/`

## 9. Deploy Railway

1. Push โปรเจกต์ขึ้น GitHub
2. เข้า Railway
3. New Project
4. Deploy from GitHub Repo
5. เพิ่ม Environment Variables จาก `.env.example`
6. Deploy
7. ทดสอบ `/health`
8. นำ Railway Domain ไปใส่ LINE Webhook

## 10. ทดสอบ

```bash
npm test
```

## สิ่งที่ควรเพิ่มใน Phase 2

- OpenAI Responses API / tool calling
- PostgreSQL / Supabase
- Admin authentication
- Dashboard UI
- Customer memory แบบ persistent
- Google Sheets
- Gmail / Calendar
- Shopee / TikTok / Facebook integrations
- Make.com webhook
- Scheduler / alert engine
- Audit log แบบฐานข้อมูล

## หมายเหตุด้านความปลอดภัย

อย่า commit `.env`
อย่าใส่ API Key / Token / Secret ลงใน GitHub
อย่าใช้ JSON เป็นฐานข้อมูลถาวรเมื่อระบบเริ่มมีลูกค้าจริงจำนวนมาก
