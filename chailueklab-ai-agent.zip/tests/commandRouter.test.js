import test from "node:test";
import assert from "node:assert/strict";
import { runCommand } from "../src/commands/commandRouter.js";

test("/help returns command list", async () => {
  const result = await runCommand("/help");
  assert.match(result, /\/สินค้า/);
});
