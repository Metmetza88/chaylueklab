import { Router } from "express";
import { getProducts } from "../services/productService.js";
import { getOrders, getTodaySales } from "../services/orderService.js";
import { getCustomers } from "../services/customerService.js";
import { runCommand } from "../commands/commandRouter.js";

export const apiRouter = Router();

apiRouter.get("/dashboard", async (_req, res, next) => {
  try {
    const [sales, products, orders, customers] = await Promise.all([
      getTodaySales(), getProducts(), getOrders(), getCustomers()
    ]);
    res.json({
      salesToday: sales,
      productCount: products.length,
      orderCount: orders.length,
      customerCount: customers.length
    });
  } catch (err) { next(err); }
});

apiRouter.get("/sales/today", async (_req, res, next) => {
  try { res.json(await getTodaySales()); } catch (err) { next(err); }
});

apiRouter.get("/products", async (_req, res, next) => {
  try { res.json(await getProducts()); } catch (err) { next(err); }
});

apiRouter.get("/orders", async (_req, res, next) => {
  try { res.json(await getOrders()); } catch (err) { next(err); }
});

apiRouter.get("/customers", async (_req, res, next) => {
  try { res.json(await getCustomers()); } catch (err) { next(err); }
});

apiRouter.post("/commands", async (req, res, next) => {
  try {
    const text = String(req.body?.command || "").trim();
    const [command, ...args] = text.split(/\s+/);
    const output = await runCommand(command, args, { source: "api" });
    res.json({ ok: true, output });
  } catch (err) { next(err); }
});
