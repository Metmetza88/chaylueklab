import { Router } from "express";

export const healthRouter = Router();

healthRouter.get("/", (_req, res) => {
  res.json({
    status: "ok",
    ai: true,
    database: true,
    line: true,
    timestamp: new Date().toISOString()
  });
});
