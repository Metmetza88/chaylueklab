import { Router } from "express";
import { env } from "../config/env.js";
import { runCommand } from "../commands/commandRouter.js";
import { replyLine } from "../services/lineService.js";
import { log } from "../utils/logger.js";

export const lineRouter = Router();

lineRouter.post("/", async (req, res) => {
  res.sendStatus(200);

  const events = Array.isArray(req.body?.events) ? req.body.events : [];

  for (const event of events) {
    try {
      if (event.type !== "message" || event.message?.type !== "text") continue;

      const text = String(event.message.text || "").trim();
      const isGroup = ["group", "room"].includes(event.source?.type);

      if (isGroup && env.groupCommandOnly && !text.startsWith("/")) continue;
      if (!env.customerBotEnabled && !text.startsWith("/")) continue;

      let output;
      if (text.startsWith("/")) {
        const [command, ...args] = text.split(/\s+/);
        output = await runCommand(command, args, {
          userId: event.source?.userId,
          groupId: event.source?.groupId
        });
      } else {
        output = "สวัสดีครับ ระบบ AI พร้อมใช้งาน พิมพ์ /help เพื่อดูคำสั่ง หรือสอบถามข้อมูลสินค้าได้";
      }

      await replyLine(event.replyToken, [{ type: "text", text: output }]);

      log("info", "line_message_processed", {
        userId: event.source?.userId,
        sourceType: event.source?.type,
        command: text.startsWith("/") ? text.split(/\s+/)[0] : null
      });
    } catch (error) {
      log("error", "line_message_failed", { error: error.message });
    }
  }
});
