import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";

import { healthRouter } from "./routes/health.js";
import { apiRouter } from "./routes/api.js";
import { lineRouter } from "./routes/lineWebhook.js";
import { errorHandler } from "./middleware/errorHandler.js";

export const app = express();

app.use(helmet());
app.use(cors());
app.use(rateLimit({ windowMs: 60_000, limit: 120 }));
app.use(express.json({ limit: "1mb" }));

app.get("/", (_req, res) => {
  res.json({
    name: "CHAILUEKLAB AI",
    status: "running",
    endpoints: ["/health", "/api/dashboard", "/webhook/line"]
  });
});

app.use("/health", healthRouter);
app.use("/api", apiRouter);
app.use("/webhook/line", lineRouter);

app.use(errorHandler);
