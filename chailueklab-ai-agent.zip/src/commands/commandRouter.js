import { getProducts, getLowStock } from "../services/productService.js";
import { getOrder, getTodaySales } from "../services/orderService.js";

export async function runCommand(command, args = [], context = {}) {
  switch (command) {
    case "/help":
      return "คำสั่ง: /help /status /สินค้า /สต็อก /ยอดวันนี้ /ออเดอร์ <เลขออเดอร์>";
    case "/status":
    case "/health":
      return "ระบบ CHAILUEKLAB AI ทำงานปกติ";
    case "/สินค้า": {
      const products = await getProducts();
      if (!products.length) return "ยังไม่มีสินค้าในระบบ";
      return products.map(p => `${p.name} | ${p.salePrice ?? p.normalPrice} บาท | คงเหลือ ${p.stock}`).join("\n");
    }
    case "/สต็อก": {
      const items = await getLowStock(5);
      return items.length
        ? "สินค้าใกล้หมด:\n" + items.map(p => `${p.name}: ${p.stock}`).join("\n")
        : "ยังไม่มีสินค้าใกล้หมด";
    }
    case "/ยอดวันนี้": {
      const sales = await getTodaySales();
      return `ยอดวันนี้\nออเดอร์: ${sales.orders}\nรายได้ชำระแล้ว: ${sales.revenue} บาท`;
    }
    case "/ออเดอร์": {
      const orderId = args[0];
      if (!orderId) return "กรุณาระบุเลขออเดอร์ เช่น /ออเดอร์ ORD-DEMO-001";
      const order = await getOrder(orderId);
      if (!order) return "ไม่พบออเดอร์นี้";
      return `ออเดอร์ ${order.orderId}\nสถานะ: ${order.orderStatus}\nชำระเงิน: ${order.paymentStatus}\nยอดรวม: ${order.total} บาท`;
    }
    default:
      return "ไม่รู้จักคำสั่งนี้ พิมพ์ /help เพื่อดูคำสั่งทั้งหมด";
  }
}
