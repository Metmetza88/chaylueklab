const memory = new Map();
const TTL_MS = 30 * 60 * 1000;

export function setMemory(userId, value) {
  memory.set(userId, { value, expiresAt: Date.now() + TTL_MS });
}

export function getMemory(userId) {
  const entry = memory.get(userId);
  if (!entry) return null;
  if (entry.expiresAt < Date.now()) {
    memory.delete(userId);
    return null;
  }
  return entry.value;
}
