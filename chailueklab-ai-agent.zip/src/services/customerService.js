import { readJson } from "../repositories/jsonRepository.js";

const file = new URL("../../data/customers.json", import.meta.url);

export async function getCustomers() {
  return readJson(file);
}
