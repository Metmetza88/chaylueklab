import crypto from "crypto";
import { env } from "../config/env.js";

export function verifyLineSignature(rawBody, signature) {
  if (!env.lineChannelSecret) return false;
  const digest = crypto
    .createHmac("SHA256", env.lineChannelSecret)
    .update(rawBody)
    .digest("base64");
  return crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(signature || ""));
}

export async function replyLine(replyToken, messages) {
  if (!env.lineAccessToken) {
    return { skipped: true, reason: "LINE_CHANNEL_ACCESS_TOKEN not configured" };
  }

  const response = await fetch("https://api.line.me/v2/bot/message/reply", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${env.lineAccessToken}`
    },
    body: JSON.stringify({
      replyToken,
      messages: Array.isArray(messages) ? messages : [{ type: "text", text: String(messages) }]
    })
  });

  if (!response.ok) {
    throw new Error(`LINE reply failed: ${response.status} ${await response.text()}`);
  }

  return { ok: true };
}
