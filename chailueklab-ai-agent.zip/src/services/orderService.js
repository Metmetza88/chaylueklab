import { readJson } from "../repositories/jsonRepository.js";

const file = new URL("../../data/orders.json", import.meta.url);

export async function getOrders() {
  return readJson(file);
}

export async function getOrder(orderId) {
  const orders = await getOrders();
  return orders.find(o => o.orderId === orderId) || null;
}

export async function getTodaySales() {
  const orders = await getOrders();
  const today = new Date().toISOString().slice(0, 10);
  const todayOrders = orders.filter(o => String(o.createdAt || "").slice(0, 10) === today);
  const revenue = todayOrders
    .filter(o => o.paymentStatus === "paid")
    .reduce((sum, o) => sum + Number(o.total || 0), 0);

  return {
    date: today,
    orders: todayOrders.length,
    revenue
  };
}
