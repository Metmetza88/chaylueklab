import { readJson } from "../repositories/jsonRepository.js";

const file = new URL("../../data/products.json", import.meta.url);

export async function getProducts() {
  return readJson(file);
}

export async function searchProducts(query) {
  const products = await getProducts();
  const q = String(query || "").toLowerCase().trim();
  return products.filter(p =>
    p.active &&
    [p.name, p.sku, p.category, p.description]
      .filter(Boolean)
      .some(v => String(v).toLowerCase().includes(q))
  );
}

export async function getLowStock(limit = 5) {
  const products = await getProducts();
  return products.filter(p => p.active && Number(p.stock) <= limit);
}
