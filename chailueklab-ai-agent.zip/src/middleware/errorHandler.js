import { log } from "../utils/logger.js";

export function errorHandler(err, req, res, _next) {
  log("error", "request_failed", {
    method: req.method,
    path: req.path,
    error: err.message
  });

  res.status(500).json({
    ok: false,
    error: "internal_server_error"
  });
}
