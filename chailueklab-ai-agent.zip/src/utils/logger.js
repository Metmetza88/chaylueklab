export function log(level, message, meta = {}) {
  const safeMeta = { ...meta };
  for (const key of Object.keys(safeMeta)) {
    if (/token|secret|password|api.?key/i.test(key)) safeMeta[key] = "[REDACTED]";
  }
  console.log(JSON.stringify({
    timestamp: new Date().toISOString(),
    level,
    message,
    ...safeMeta
  }));
}
