import { app } from "./app.js";
import { env } from "./config/env.js";
import { log } from "./utils/logger.js";

const server = app.listen(env.port, () => {
  log("info", "server_started", { port: env.port });
});

function shutdown(signal) {
  log("info", "shutdown_requested", { signal });
  server.close(() => {
    log("info", "server_stopped");
    process.exit(0);
  });
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
