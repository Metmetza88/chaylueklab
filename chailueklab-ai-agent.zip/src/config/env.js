import dotenv from "dotenv";
dotenv.config();

export const env = {
  port: Number(process.env.PORT || 3000),
  aiProvider: process.env.AI_PROVIDER || "mock",
  openaiApiKey: process.env.OPENAI_API_KEY || "",
  openaiModel: process.env.OPENAI_MODEL || "gpt-5",
  lineAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN || "",
  lineChannelSecret: process.env.LINE_CHANNEL_SECRET || "",
  adminUsers: (process.env.ADMIN_USERS || "").split(",").map(v => v.trim()).filter(Boolean),
  groupCommandOnly: String(process.env.GROUP_COMMAND_ONLY || "true").toLowerCase() === "true",
  customerBotEnabled: String(process.env.CUSTOMER_BOT_ENABLED || "true").toLowerCase() === "true"
};
