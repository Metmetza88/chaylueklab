import Stripe from "npm:stripe@23.0.0";
import {adminDb,lineIdentity,isOwner,CORS,json} from "../_shared/membership.ts";

const resources:Record<string,{table:string,columns:string}>={
  reminders:{table:"line_reminders",columns:"id,line_user_id,target_id,title,remind_at,status,requester_name,group_name,error,created_at"},
  tasks:{table:"line_tasks",columns:"id,line_user_id,target_id,title,status,due_at,requester_name,group_name,created_at"},
  finances:{table:"line_finances",columns:"id,line_user_id,target_id,title,entry_type,amount,created_at"},
  notes:{table:"line_notes",columns:"id,line_user_id,target_id,note,created_at"},
  files:{table:"line_files",columns:"id,line_user_id,target_id,file_name,mime_type,size_bytes,storage_path,created_at"},
  issues:{table:"line_issues",columns:"id,line_user_id,target_id,detail,created_at"},
  subscriptions:{table:"billing_subscriptions",columns:"stripe_subscription_id,line_user_id,status,paid,current_period_end,cancel_at_period_end,updated_at"},
  access:{table:"member_access_overrides",columns:"line_user_id,mode,expires_at,updated_at"},
  audit:{table:"admin_audit",columns:"id,actor_id,action,resource,record_id,created_at"}
};
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export function allowedPatch(resource:string,patch:any){
  if(!patch||typeof patch!=="object"||Array.isArray(patch))throw new Error("invalid_patch");
  const out:any={};
  const fields:Record<string,string[]>={reminders:["title","remind_at","status"],tasks:["title","due_at","status"],finances:["title","amount","entry_type"],notes:["note"],issues:["detail"]};
  const allowed=fields[resource];if(!allowed)throw new Error("resource_readonly");
  for(const k of Object.keys(patch)){
    if(!allowed.includes(k))throw new Error("field_not_allowed");
    const value=patch[k];
    if(["title","note","detail"].includes(k)){if(typeof value!=="string"||!value.trim()||value.length>(k==="title"?500:5000))throw new Error("invalid_text");out[k]=value.trim();}
    if(k==="amount"){if(!Number.isFinite(Number(value))||Number(value)<=0||Number(value)>1e12)throw new Error("invalid_amount");out[k]=Number(value);}
    if(k==="entry_type"){if(!["income","expense"].includes(value))throw new Error("invalid_type");out[k]=value;}
    if(k==="status"){if(!["pending","done","cancelled"].includes(value))throw new Error("invalid_status");out[k]=value;}
    if(k==="remind_at"||k==="due_at"){
      if(k==="due_at"&&value===null){out[k]=null;continue;}
      const d=new Date(value);if(!Number.isFinite(d.getTime()))throw new Error("invalid_date");out[k]=d.toISOString();
    }
  }
  if(!Object.keys(out).length)throw new Error("empty_patch");
  if(resource==="tasks"&&out.status)out.completed_at=out.status==="done"?new Date().toISOString():null;
  return out;
}
Deno.serve(async(req:Request)=>{
  if(req.method==="OPTIONS")return new Response("ok",{headers:CORS});
  if(req.method!=="POST")return json({ok:false,error:"method_not_allowed"},405);
  try{
    let b;try{b=await req.json()}catch{return json({ok:false,error:"invalid_json"},400)}
    const user=await lineIdentity(b);if(!user)return json({ok:false,error:"invalid_line_login"},401);
    const db=adminDb();if(!await isOwner(db,user))return json({ok:false,error:"owner_only"},403);
    if(b.action==="members"){
      const r=await db.rpc("admin_member_list");if(r.error)throw r.error;return json({ok:true,rows:r.data,limit:500});
    }
    if(b.action==="access"){
      if(typeof b.user!=="string"||!/^U[0-9a-f]{32}$/i.test(b.user)||!["grant","block","reset"].includes(b.mode))return json({ok:false,error:"invalid_access"},400);
      if(await isOwner(db,b.user)&&b.mode==="block")return json({ok:false,error:"cannot_block_owner"},400);
      let r;
      if(b.mode==="reset")r=await db.from("member_access_overrides").delete().eq("line_user_id",b.user);
      else{
        const days=Number(b.days||30);if(!Number.isInteger(days)||days<1||days>365)return json({ok:false,error:"invalid_days"},400);
        r=await db.from("member_access_overrides").upsert({line_user_id:b.user,mode:b.mode,expires_at:b.mode==="grant"?new Date(Date.now()+days*86400000).toISOString():null,updated_by:user,updated_at:new Date().toISOString()});
      }
      if(r.error)throw r.error;
      await db.from("admin_audit").insert({actor_id:user,action:b.mode,resource:"access",record_id:b.user});
      return json({ok:true});
    }
    const resource=resources[b.resource];if(!resource)return json({ok:false,error:"invalid_resource"},400);
    if(b.action==="list"){
      const offset=Math.max(0,Number(b.offset)||0);
      if(!Number.isInteger(offset)||offset>100000)return json({ok:false,error:"invalid_offset"},400);
      let q=db.from(resource.table).select(resource.columns,{count:"exact"});
      if(b.user){if(typeof b.user!=="string"||!/^U[0-9a-f]{32}$/i.test(b.user))return json({ok:false,error:"invalid_user"},400);q=q.eq(b.resource==="audit"?"actor_id":"line_user_id",b.user);}
      const r=await q.order(["subscriptions","access"].includes(b.resource)?"updated_at":"created_at",{ascending:false}).range(offset,offset+49);
      if(r.error)throw r.error;
      let rows=r.data||[];
      if(b.resource==="files")rows=await Promise.all(rows.map(async(f:any)=>{const signed=await db.storage.from("chaylueklab-files").createSignedUrl(f.storage_path,600);return {...f,url:signed.data?.signedUrl||null};}));
      return json({ok:true,rows,total:r.count,offset,limit:50});
    }
    if(b.action==="cancel_subscription"&&b.resource==="subscriptions"){
      const row=await db.from("billing_subscriptions").select("stripe_subscription_id").eq("stripe_subscription_id",String(b.id)).maybeSingle();
      if(row.error)throw row.error;if(!row.data)return json({ok:false,error:"not_found"},404);
      const key=Deno.env.get("STRIPE_SECRET_KEY");if(!key)return json({ok:false,error:"billing_not_configured"},503);
      const stripe=new Stripe(key,{httpClient:Stripe.createFetchHttpClient()});
      await stripe.subscriptions.update(row.data.stripe_subscription_id,{cancel_at_period_end:true});
      await db.from("admin_audit").insert({actor_id:user,action:"cancel_at_period_end",resource:"subscriptions",record_id:b.id});
      return json({ok:true,pendingWebhook:true});
    }
    if(!["update","delete"].includes(b.action)||!["reminders","tasks","finances","notes","files","issues"].includes(b.resource)||!uuid.test(String(b.id)))return json({ok:false,error:"invalid_operation"},400);
    if(b.action==="update"){
      let patch;try{patch=allowedPatch(b.resource,b.patch)}catch(e){return json({ok:false,error:(e as Error).message},400)}
      let q=db.from(resource.table).update(patch).eq("id",b.id);
      if(b.resource==="reminders")q=q.neq("status","queued");
      const r=await q.select("id").maybeSingle();if(r.error)throw r.error;if(!r.data)return json({ok:false,error:"not_found_or_in_transit"},409);
    }else{
      if(b.resource==="files"){
        const f=await db.from("line_files").select("storage_path").eq("id",b.id).maybeSingle();
        if(f.error)throw f.error;if(!f.data)return json({ok:false,error:"not_found"},404);
        const rm=await db.storage.from("chaylueklab-files").remove([f.data.storage_path]);if(rm.error)throw rm.error;
      }
      let q=db.from(resource.table).delete().eq("id",b.id);
      if(b.resource==="reminders")q=q.neq("status","queued");
      const r=await q.select("id").maybeSingle();if(r.error)throw r.error;if(!r.data)return json({ok:false,error:"not_found_or_in_transit"},409);
    }
    await db.from("admin_audit").insert({actor_id:user,action:b.action,resource:b.resource,record_id:b.id});
    return json({ok:true});
  }catch(e){console.error("owner action failed",e instanceof Error?e.message:"unknown");return json({ok:false,error:"admin_unavailable"},500);}
});
