import Stripe from "npm:stripe@23.0.0";
import {adminDb,lineIdentity,membership,isOwner,PLAN,CORS,json,billingEnabled,billingReady} from "../_shared/membership.ts";

const APP="https://liff.line.me/2011681452-k1lfYGsF?view=membership";
function stripeClient(){
  const key=Deno.env.get("STRIPE_SECRET_KEY");
  if(!key)throw new Error("stripe_not_configured");
  return new Stripe(key,{httpClient:Stripe.createFetchHttpClient(),maxNetworkRetries:2});
}
async function portal(stripe:any,customer:string){
  let configuration=Deno.env.get("STRIPE_PORTAL_CONFIGURATION_ID");
  if(!configuration){
    const configs=await stripe.billingPortal.configurations.list({limit:100});
    const existing=configs.data.find((c:any)=>c.active&&c.metadata?.app==="chaylueklab_99"&&c.features?.subscription_cancel?.enabled&&c.features.subscription_cancel.mode==="at_period_end");
    if(existing)configuration=existing.id;
    else{
      const created=await stripe.billingPortal.configurations.create({
        business_profile:{headline:"จัดการสมาชิก CHAYLUEKLAB"},metadata:{app:"chaylueklab_99"},
        features:{subscription_cancel:{enabled:true,mode:"at_period_end"},payment_method_update:{enabled:true},invoice_history:{enabled:true}}
      },{idempotencyKey:"chaylueklab-portal-99"});
      configuration=created.id;
    }
  }
  const p=await stripe.billingPortal.sessions.create({customer,return_url:APP,...(configuration?{configuration}:{})});
  return p.url;
}
Deno.serve(async(req:Request)=>{
  if(req.method==="GET"){const key=Deno.env.get("STRIPE_SECRET_KEY")||"";return json({ok:true,plan:PLAN,checkoutReady:billingReady(),billingEnforced:billingEnabled(),mode:key.startsWith("sk_live_")?"live":key?"test":"unconfigured"});}
  if(req.method==="OPTIONS")return new Response("ok",{headers:CORS});
  if(req.method!=="POST")return json({ok:false,error:"method_not_allowed"},405);
  let db:any,user:string|null=null,lease:string|null=null;
  try{
    let body;try{body=await req.json()}catch{return json({ok:false,error:"invalid_json"},400)}
    user=await lineIdentity(body);if(!user)return json({ok:false,error:"invalid_line_login"},401);
    db=adminDb();
    if(body.action==="status"){
      const m=await membership(db,user);
      const customer=await db.from("billing_customers").select("stripe_customer_id").eq("line_user_id",user).maybeSingle();
      if(customer.error)throw customer.error;
      const key=Deno.env.get("STRIPE_SECRET_KEY")||"";
      return json({ok:true,plan:PLAN,membership:m,checkoutReady:billingReady(),billingEnforced:billingEnabled(),mode:key.startsWith("sk_live_")?"live":key?"test":"unconfigured",canManage:!!customer.data?.stripe_customer_id&&billingReady()});
    }
    if(body.action==="admin_summary"){
      if(!await isOwner(db,user))return json({ok:false,error:"forbidden"},403);
      const r=await db.from("billing_subscriptions").select("line_user_id,status,paid,current_period_end,cancel_at_period_end").order("updated_at",{ascending:false}).limit(100);
      if(r.error)throw r.error;
      return json({ok:true,subscriptions:r.data,plan:PLAN});
    }
    if(!["checkout","portal"].includes(body.action))return json({ok:false,error:"unknown_action"},400);
    if(!billingReady())return json({ok:false,error:"billing_not_configured"},503);
    const stripe=stripeClient();
    let customerRow=await db.from("billing_customers").select("stripe_customer_id").eq("line_user_id",user).maybeSingle();
    if(customerRow.error)throw customerRow.error;
    if(body.action==="portal"){
      if(!customerRow.data?.stripe_customer_id)return json({ok:false,error:"no_subscription"},404);
      return json({ok:true,url:await portal(stripe,customerRow.data.stripe_customer_id)});
    }
    const access=await membership(db,user);
    if(access.status==="blocked")return json({ok:false,error:"account_suspended"},403);
    lease=crypto.randomUUID();
    const reserved=await db.rpc("billing_reserve_checkout",{p_user:user,p_token:lease});
    if(reserved.error)throw reserved.error;
    if(reserved.data.cached){lease=null;return json({ok:true,url:reserved.data.url});}
    if(reserved.data.busy){lease=null;return json({ok:false,error:"checkout_in_progress"},409);}
    if(!reserved.data.acquired)throw new Error("checkout_reservation_failed");
    let customer=reserved.data.customer;
    if(!customer){
      const c=await stripe.customers.create({metadata:{line_user_id:user}},{idempotencyKey:"chaylueklab-customer-"+user});
      customer=c.id;
      const saved=await db.from("billing_customers").update({stripe_customer_id:customer}).eq("line_user_id",user).eq("checkout_token",lease);
      if(saved.error)throw saved.error;
    }
    // Existing subscriptions are managed in the portal to prevent double billing.
    const subscriptions=await stripe.subscriptions.list({customer,status:"all",limit:100});
    if(subscriptions.data.some((s:any)=>!["canceled","incomplete_expired"].includes(s.status))){
      const url=await portal(stripe,customer);
      await db.from("billing_customers").update({checkout_token:null,checkout_lease_until:null}).eq("line_user_id",user).eq("checkout_token",lease);
      lease=null;return json({ok:true,url,existingSubscription:true});
    }
    const session=await stripe.checkout.sessions.create({
      mode:"subscription",customer,payment_method_types:["card"],client_reference_id:user,
      line_items:[{price_data:{currency:PLAN.currency,unit_amount:PLAN.amount,recurring:{interval:"month"},product_data:{name:PLAN.name,description:"งาน ตั้งเตือน การเงิน ไฟล์และโน้ต ผ่านบัญชี LINE ส่วนตัว"}},quantity:1}],
      subscription_data:{metadata:{line_user_id:user,plan:"chaylueklab_monthly_99"}},
      metadata:{line_user_id:user},success_url:APP+"&payment=success",cancel_url:APP+"&payment=cancelled",
      expires_at:Math.floor(Date.now()/1000)+1800,locale:"th",
      custom_text:{submit:{message:"99 บาทต่อเดือน ต่ออายุอัตโนมัติ ยกเลิกได้ผ่านหน้าจัดการสมาชิก โดยใช้ต่อได้จนสิ้นรอบที่ชำระแล้ว"}}
    },{idempotencyKey:"chaylueklab-checkout-"+lease});
    if(!session.url)throw new Error("checkout_url_unavailable");
    const saved=await db.from("billing_customers").update({checkout_session_id:session.id,checkout_url:session.url,checkout_expires_at:new Date(session.expires_at*1000).toISOString(),checkout_lease_until:null,checkout_token:null}).eq("line_user_id",user).eq("checkout_token",lease);
    if(saved.error)throw saved.error;
    lease=null;return json({ok:true,url:session.url});
  }catch(e){
    if(db&&user&&lease)await db.from("billing_customers").update({checkout_token:null,checkout_lease_until:null}).eq("line_user_id",user).eq("checkout_token",lease);
    console.error("billing request failed",e instanceof Error?e.message:"unknown");
    return json({ok:false,error:"billing_unavailable"},502);
  }
});
