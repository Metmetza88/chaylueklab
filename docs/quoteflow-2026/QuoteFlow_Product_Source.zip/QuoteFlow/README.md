# QuoteFlow source kit 1.0 preparation edition

Source snapshot: ad4154fac29906ad28eb1c1b064dce847a9df859 in Metmetza88/chaylueklab.

This is the source of a working static quotation-review app and a draft product offer, not a live hosted subscription. Final sale and license terms have not been accepted. Reused core ownership remains for the owner to confirm. No new repository-wide license is granted by this archive. Third-party notices are preserved.

## ใช้งานบน Windows

ติดตั้ง Python 3 จาก python.org หากยังไม่มี จากนั้นเปิด start-windows.bat เว็บจะเปิดที่ http://127.0.0.1:4173/ai-money-studio/quote-flow.html เก็บหน้าต่างเซิร์ฟเวอร์ไว้ระหว่างใช้งาน กด Ctrl+C ในหน้าต่างนั้นเพื่อหยุด

## Linux or another local static server

Run python3 -m http.server 4173 --bind 127.0.0.1 from the kit directory. Open http://127.0.0.1:4173/ai-money-studio/quote-flow.html. A normal HTTP/HTTPS static host also works. Preserve relative paths, serve .mjs as JavaScript and keep the worker and font files available. Do not open the HTML file directly with file://.

## iPhone

Open an HTTPS-hosted copy in Safari. Opening HTML directly in Files is unsupported. Physical iPhone Safari file-picker/download/print tests are still pending; the included checks used Chromium viewport emulation. The immutable demonstration URL is in LINKS.json. Its first visit may display Open the page. It is a third-party experimental preview, not the hosted paid product.

## Workflow

1. Import a supported file, or try the synthetic 30-item example.
2. Enter the count independently from the original document. Inspect every name, quantity, unit and price. Confirm reviewed rows. Check duplicate candidates explicitly.
3. Complete seller, customer, quote number and date. Print to PDF or download items. Download a JSON draft before closing; restoring it resets reviews.

## Supported inputs and boundaries

CSV/TSV/TXT must be UTF-8 and at most 512 KiB. XLSX must contain a single sheet with no formulas/merged cells. DOCX must use tables with recognizable headings. PDF must contain selectable text, supported column headers on every page, and no more than 50 pages. Scans/photos, rotated tables and multi-line PDF item descriptions are not supported. All formats are limited to 10 MiB and 500 rows. THB and whole positive quantities only. No tax/discount engine, account, cloud history, payment processing, automatic sending or LINE integration.

## Privacy and AI disclosure

Documents are parsed in the browser. No document upload or model API is implemented. App assets load from the host. There is no automatic persistence. JSON draft downloads may contain customer details; keep them under your control. The app was built with AI coding assistance; it does not run an AI model or scanned-document OCR.

## Verification

Run node --test tests/quote-flow.test.mjs tests/quoteflow-review.test.mjs for the 22 QuoteFlow unit checks included in this kit. The full parent repository passed 149 tests. The 21 browser checks, including four exact 30-row fixtures, are recorded in VALIDATION.json. Six viewport widths were checked with Chromium 156, not with physical iPhone Safari or Windows. All sample documents and prices are synthetic. A matching item count does not prove semantic correctness.

## Dependencies

PDF.js 5.6.205 with its Apache 2.0 license and standard-font notices. JSZip with its original license notice. Noto Sans Thai under the included OFL notice. Preserve these notices when distributing the app.
