CHAYLUEKLAB READY-TO-USE

ไฟล์หลัก:
- index.html = ใช้อัปแทนไฟล์ index.html เดิมใน GitHub repo Metmetza88/chaylueklab

ระบบที่เปิดไว้แล้วในไฟล์:
- LIFF ID: 2011681452-k1lfYGsF
- Supabase Edge Functions: bxaplhrunxiadjsdobyl
- เพิ่มงาน -> create-reminder
- ทดสอบ LINE -> line-test
- งานใหม่ขึ้น Cloud ✓ • LINE ✓ เมื่อซิงก์สำเร็จ
- ไม่มี LINE Channel Access Token / Channel Secret ใน HTML

วิธีอัป:
1) เปิด GitHub repo Metmetza88/chaylueklab
2) เข้าไฟล์ index.html
3) กด Edit หรือ Upload files
4) แทน index.html เดิมด้วยไฟล์นี้
5) Commit changes
6) รอ GitHub Pages ประมาณ 1-2 นาที
7) เปิด https://liff.line.me/2011681452-k1lfYGsF แล้วเพิ่มงานทดสอบ
