import fs from "fs/promises";
export class JsonRepository{
 constructor(path){this.path=path}
 async all(){return JSON.parse(await fs.readFile(this.path,"utf8"))}
 async write(rows){const tmp=this.path+".tmp";await fs.writeFile(tmp,JSON.stringify(rows,null,2));await fs.rename(tmp,this.path)}
 async find(fn){return (await this.all()).find(fn)}
 async filter(fn){return (await this.all()).filter(fn)}
 async insert(row){const rows=await this.all();rows.push(row);await this.write(rows);return row}
 async update(fn,patch){const rows=await this.all();const i=rows.findIndex(fn);if(i<0)return null;rows[i]={...rows[i],...patch};await this.write(rows);return rows[i]}
}