import {Router,raw} from "express";import crypto from "crypto";import {env} from "../config/env.js";import {replyLine} from "../services/lineService.js";import {runCommand} from "../commands/commandRouter.js";import {classify} from "../services/intentService.js";import {mainAgent} from "../agents/mainAgent.js";import {productService} from "../services/productService.js";import {audit} from "../services/auditService.js";
const r=Router();
function valid(buf,sig){if(!env.LINE_CHANNEL_SECRET||!sig)return false;const h=crypto.createHmac("sha256",env.LINE_CHANNEL_SECRET).update(buf).digest("base64");try{return crypto.timingSafeEqual(Buffer.from(h),Buffer.from(sig))}catch{return false}}
r.post("/",raw({type:"application/json",limit:"1mb"}),async(req,res,next)=>{try{
 if(!valid(req.body,req.get("x-line-signature")))return res.status(401).send("invalid signature");
 const body=JSON.parse(req.body.toString("utf8"));res.sendStatus(200);
 for(const e of body.events||[]){if(e.type!=="message"||e.message?.type!=="text"||!e.replyToken)continue;
  const text=e.message.text.trim(), userId=e.source?.userId||"", isGroup=e.source?.type==="group";
  if(isGroup&&env.GROUP_COMMAND_ONLY&&!text.startsWith("/"))continue;
  if(!env.CUSTOMER_BOT_ENABLED&&!text.startsWith("/"))continue;
  const started=Date.now(), intent=classify(text);let answer;
  if(text.startsWith("/"))answer=await runCommand(text,userId);
  if(!answer){let context="";if(intent==="price"||intent==="stock")context=JSON.stringify(await productService.list());answer=await mainAgent(text,context)}
  await replyLine(e.replyToken,answer||"ไม่พบข้อมูล กรุณาติดต่อผู้ดูแล");
  await audit({userId,source:"line",intent,command:text.startsWith("/")?text.split(" ")[0]:undefined,action:"reply",result:"ok",responseTime:Date.now()-started});
 }}catch(err){next(err)}});export default r;