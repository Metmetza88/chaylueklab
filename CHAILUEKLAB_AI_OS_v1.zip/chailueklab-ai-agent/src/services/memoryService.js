import {env} from "../config/env.js"; const store=new Map();
export const memoryService={
 get(id){const v=store.get(id);if(!v||v.expires<Date.now()){store.delete(id);return null}return v.data},
 set(id,data){store.set(id,{data,expires:Date.now()+env.MEMORY_TTL_MINUTES*60000})},
 clear(id){store.delete(id)}
};