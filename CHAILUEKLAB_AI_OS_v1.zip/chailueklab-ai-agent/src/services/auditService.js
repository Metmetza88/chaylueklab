import {JsonRepository} from "../repositories/jsonRepository.js"; import {now} from "../utils/helpers.js";
const repo=new JsonRepository("data/logs.json");
export async function audit(e){const safe={timestamp:now(),requestId:e.requestId,userId:e.userId,source:e.source,intent:e.intent,command:e.command,action:e.action,result:e.result,responseTime:e.responseTime,error:e.error};await repo.insert(safe);return safe}
export const getLogs=()=>repo.all();