import crypto from "crypto"; import {orderRepository as repo} from "../repositories/orderRepository.js"; import {now} from "../utils/helpers.js";
export const orderService={
 list:()=>repo.all(), get:id=>repo.find(x=>x.orderId===id),
 byCustomer:id=>repo.filter(x=>x.customerId===id),
 async create(data){const row={orderId:"ORD-"+crypto.randomUUID().slice(0,8).toUpperCase(),paymentStatus:"pending",orderStatus:"pending",createdAt:now(),updatedAt:now(),...data};return repo.insert(row)},
 update:(id,patch)=>repo.update(x=>x.orderId===id,{...patch,updatedAt:now()})
};