import {productRepository as repo} from "../repositories/productRepository.js";
export const productService={
 list:()=>repo.all(),
 get:id=>repo.find(x=>x.productId===id||x.sku===id),
 search:async q=>(await repo.all()).filter(x=>x.active!==false&&(x.name?.toLowerCase().includes(q.toLowerCase())||x.sku?.toLowerCase().includes(q.toLowerCase()))),
 stock:async()=> (await repo.all()).filter(x=>x.active!==false).map(({productId,sku,name,stock})=>({productId,sku,name,stock}))
};