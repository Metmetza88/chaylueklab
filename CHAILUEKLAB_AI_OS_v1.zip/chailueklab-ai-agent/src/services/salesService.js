import {orderRepository as repo} from "../repositories/orderRepository.js";
const calc=rows=>{const valid=rows.filter(x=>x.orderStatus!=="cancelled");const revenue=valid.reduce((s,x)=>s+Number(x.total||0),0);const items=valid.reduce((s,x)=>s+(x.products||[]).reduce((a,p)=>a+Number(p.quantity||0),0),0);return {orders:valid.length,items,revenue}};
export const salesService={
 async today(){const d=new Date().toISOString().slice(0,10);return calc((await repo.all()).filter(x=>x.createdAt?.startsWith(d)))},
 async month(){const d=new Date().toISOString().slice(0,7);return calc((await repo.all()).filter(x=>x.createdAt?.startsWith(d)))}
};