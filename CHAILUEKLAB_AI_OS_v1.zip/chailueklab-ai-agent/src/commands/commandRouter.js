import {adminUsers,env} from "../config/env.js";import {salesService} from "../services/salesService.js";import {productService} from "../services/productService.js";import {orderService} from "../services/orderService.js";import {customerService} from "../services/customerService.js";import {money} from "../utils/helpers.js";
const admin=new Set(["/เปิดบอท","/ปิดบอท","/ลูกค้า","/รายงาน","/แจ้งเตือน"]);
export async function runCommand(text,userId){
 const [cmd,arg]=text.trim().split(/\s+/,2); if(admin.has(cmd)&&!adminUsers.has(userId))return "⛔ คำสั่งนี้สำหรับ Admin";
 if(cmd==="/help")return "/status /ยอดวันนี้ /ยอดเดือนนี้ /สินค้า /สต็อก /ออเดอร์ <id> /health";
 if(cmd==="/status"||cmd==="/health")return "🟢 CHAILUEKLAB AI ทำงานอยู่";
 if(cmd==="/ยอดวันนี้"){const x=await salesService.today();return `ยอดวันนี้\nออเดอร์ ${x.orders}\nสินค้า ${x.items}\nรายได้ ${money(x.revenue)}`}
 if(cmd==="/ยอดเดือนนี้"){const x=await salesService.month();return `ยอดเดือนนี้\nออเดอร์ ${x.orders}\nสินค้า ${x.items}\nรายได้ ${money(x.revenue)}`}
 if(cmd==="/สินค้า")return JSON.stringify(await productService.list());
 if(cmd==="/สต็อก")return JSON.stringify(await productService.stock());
 if(cmd==="/ออเดอร์"){if(!arg)return "กรุณาใส่เลขออเดอร์ เช่น /ออเดอร์ ORD-XXXX";const x=await orderService.get(arg);return x?`ออเดอร์ ${x.orderId}: ${x.orderStatus} | ชำระเงิน: ${x.paymentStatus}${x.trackingNumber?` | พัสดุ: ${x.trackingNumber}`:""}`:"ไม่พบออเดอร์"}
 if(cmd==="/ลูกค้า")return `ลูกค้าในระบบ ${(await customerService.list()).length} ราย`;
 if(cmd==="/เปิดบอท"||cmd==="/ปิดบอท")return "การเปิด/ปิด runtime ต้องตั้ง CUSTOMER_BOT_ENABLED ใน Environment แล้ว restart เพื่อความปลอดภัย";
 return null;
}