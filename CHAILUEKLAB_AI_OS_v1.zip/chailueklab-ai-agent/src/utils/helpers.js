import crypto from "crypto";
export const requestId=()=>crypto.randomUUID();
export const now=()=>new Date().toISOString();
export const money=n=>new Intl.NumberFormat("th-TH",{style:"currency",currency:"THB"}).format(Number(n||0));