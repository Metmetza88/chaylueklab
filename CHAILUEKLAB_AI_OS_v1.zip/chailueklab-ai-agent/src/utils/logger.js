import pino from "pino";
export const logger=pino({redact:["req.headers.authorization","*.accessToken","*.token","*.password","*.secret","*.apiKey"]});