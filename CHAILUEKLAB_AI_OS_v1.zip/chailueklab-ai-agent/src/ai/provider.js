import OpenAI from "openai"; import {env} from "../config/env.js";
class OpenAIProvider{constructor(){this.client=env.OPENAI_API_KEY?new OpenAI({apiKey:env.OPENAI_API_KEY}):null}
 async reply({system,input}){if(!this.client)throw new Error("AI_NOT_CONFIGURED");const r=await this.client.responses.create({model:env.OPENAI_MODEL,instructions:system,input});return r.output_text}}
export const aiProvider=env.AI_PROVIDER==="openai"?new OpenAIProvider():{reply:async()=>{throw new Error("AI_PROVIDER_NOT_SUPPORTED")}};