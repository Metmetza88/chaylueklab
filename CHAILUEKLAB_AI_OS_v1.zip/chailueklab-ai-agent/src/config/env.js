import "dotenv/config";
import { z } from "zod";
const bool = z.string().default("true").transform(v => v === "true");
const schema = z.object({
 PORT:z.coerce.number().default(3000), NODE_ENV:z.string().default("development"),
 AI_PROVIDER:z.string().default("openai"), OPENAI_API_KEY:z.string().optional(),
 OPENAI_MODEL:z.string().default("gpt-5.6"), LINE_CHANNEL_ACCESS_TOKEN:z.string().optional(),
 LINE_CHANNEL_SECRET:z.string().optional(), ADMIN_USERS:z.string().default(""),
 GROUP_COMMAND_ONLY:bool, CUSTOMER_BOT_ENABLED:bool, MEMORY_TTL_MINUTES:z.coerce.number().default(60),
 API_ADMIN_KEY:z.string().optional(), CORS_ORIGIN:z.string().default("*"),
 RATE_LIMIT_MAX:z.coerce.number().default(120)
});
export const env=schema.parse(process.env);
export const adminUsers=new Set(env.ADMIN_USERS.split(",").map(x=>x.trim()).filter(Boolean));