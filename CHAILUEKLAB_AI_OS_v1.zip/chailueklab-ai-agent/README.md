# CHAILUEKLAB AI — ผู้ช่วยชายลึกลับ

Backend Node.js สำหรับ LINE OA + Owner Command Center ออกแบบให้เป็นแกนของ **CHAILUEKLAB AI Operating System** ไม่ล็อกกับธุรกิจน้ำพริก

## เริ่มใช้งาน
1. ติดตั้ง Node.js 20+
2. แตก ZIP และเปิดโฟลเดอร์
3. รัน `npm install`
4. คัดลอก `.env.example` เป็น `.env`
5. ใส่ค่าจริง แล้วรัน `npm run dev`
6. เปิด `http://localhost:3000/health`

## Environment Variables
- `PORT` พอร์ตเว็บ ปกติ 3000
- `AI_PROVIDER=openai` ผู้ให้บริการ AI
- `OPENAI_API_KEY` สร้างจาก OpenAI Platform ห้ามแชร์หรือ commit
- `OPENAI_MODEL` ชื่อโมเดลที่บัญชี API ของคุณเข้าถึงได้
- `LINE_CHANNEL_ACCESS_TOKEN` จาก LINE Developers > Messaging API channel
- `LINE_CHANNEL_SECRET` จาก LINE Developers > Basic settings
- `ADMIN_USERS` LINE userId ของ Admin คั่นด้วย comma
- `GROUP_COMMAND_ONLY=true` ให้กลุ่มตอบเฉพาะข้อความขึ้นต้น `/`
- `CUSTOMER_BOT_ENABLED=true` เปิดตอบลูกค้าทั่วไป
- `API_ADMIN_KEY` คีย์สำหรับ Owner API ส่งผ่าน header `x-api-key`
- `MEMORY_TTL_MINUTES` อายุ memory
- `CORS_ORIGIN` origin ของ dashboard
- `RATE_LIMIT_MAX` จำนวน request สูงสุดต่อนาทีต่อ IP

## LINE Webhook
หลัง Deploy ให้ตั้ง Webhook URL เป็น:
`https://โดเมนของคุณ/webhook/line`
เปิด Use webhook ใน LINE Developers แล้ว Verify endpoint ระบบตรวจ `x-line-signature` ก่อนประมวลผลทุกครั้ง

> อย่าใช้ replyToken เก่า: LINE replyToken ใช้กับ event ปัจจุบันเท่านั้น ระบบนี้ reply จาก event ที่รับเข้ามาโดยตรง

## คำสั่ง
`/help`, `/status`, `/ยอดวันนี้`, `/ยอดเดือนนี้`, `/สินค้า`, `/สต็อก`, `/ออเดอร์ <orderId>`, `/ลูกค้า`, `/health`

คำสั่งที่มีสิทธิ์สูงจะตรวจ LINE userId กับ `ADMIN_USERS`

## เพิ่มสินค้า
แก้ `data/products.json` โดยใช้ field เช่น `productId`, `sku`, `name`, `category`, `description`, `normalPrice`, `salePrice`, `stock`, `active`, `image`, `updatedAt`
ระบบอ่านราคากับสต็อกจากไฟล์จริง ไม่ให้ AI เดาเอง

## Owner API
ต้องใส่ `x-api-key: <API_ADMIN_KEY>`
- GET `/api/dashboard`
- GET `/api/sales/today`
- GET `/api/products`
- GET `/api/orders`
- GET `/api/customers`
- GET `/api/logs`
- GET `/api/health`
- POST `/api/commands`

## ทดสอบ
`npm test`
`npm run lint`

## Railway
1. สร้าง GitHub repository แล้วอัปโหลดโฟลเดอร์นี้
2. Railway > New Project > Deploy from GitHub
3. Variables: ใส่ค่าจาก `.env.example` ทีละตัว โดยใส่ secret จริงใน Railway เท่านั้น
4. Railway จะใช้ `npm start` และตรวจ `/health`
5. หลังได้ public domain ให้นำ `/webhook/line` ไปใส่ LINE Developers
6. ดู error ที่ Railway > Deployment > Logs

## Vercel
โครงสร้าง business logic ใช้ซ้ำได้ แต่ LINE webhook เหมาะกับ persistent Node deployment เช่น Railway มากกว่าในเวอร์ชันเริ่มต้นนี้

## ความปลอดภัย
ไม่มี secret hardcode, ตรวจ LINE signature, Owner API มี API key, มี rate limit/Helmet/CORS/body limits, safe structured logging และ audit log. ห้ามนำ `.env` ขึ้น GitHub

## หมายเหตุ Production
JSON repository เหมาะสำหรับเริ่มต้น/ทดสอบระบบ แต่ filesystem ของหลาย cloud platform ไม่ควรใช้เป็นฐานข้อมูลถาวร เมื่อเริ่มรับออเดอร์จริงควรเปลี่ยน repository เป็น PostgreSQL/Supabase โดย service/business logic ไม่ต้องรื้อใหม่
