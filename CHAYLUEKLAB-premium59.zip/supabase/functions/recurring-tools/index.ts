import { adminDb, CORS, json, lineIdentity, requireMember, requirePremium } from "../_shared/membership.ts";

const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ERROR_STATUS:Record<string,number>={premium_required:402,recurring_limit_reached:409,request_conflict:409,rule_not_found:404,invalid_user:400,invalid_action:400,invalid_title:400,invalid_schedule:400};

Deno.serve(async(req:Request)=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:CORS});
  if(req.method!=='POST')return json({ok:false,error:'method_not_allowed'},405);
  let body:any;
  try{body=await req.json();}catch{return json({ok:false,error:'invalid_json'},400);}
  if(!body||typeof body!=='object'||Array.isArray(body))return json({ok:false,error:'invalid_json'},400);
  try{
    const user=await lineIdentity(body);
    if(!user)return json({ok:false,error:'unauthorized'},401);
    const db=adminDb();
    const blocked=await requireMember(db,user);if(blocked)return blocked;
    const action=body.action||'list';
    if(!['list','create','pause','resume','delete'].includes(action))return json({ok:false,error:'invalid_action'},400);
    if(action==='create'||action==='resume'){
      const denial=await requirePremium(db,user);if(denial)return denial;
    }
    const args:any={p_user:user,p_action:action};
    if(['pause','resume','delete'].includes(action)){
      if(typeof body.id!=='string'||!UUID.test(body.id))return json({ok:false,error:'invalid_id'},400);
      args.p_id=body.id;
    }
    if(action==='create'){
      if(body.requestId!==undefined&&body.requestId!==null&&(typeof body.requestId!=='string'||!UUID.test(body.requestId)))return json({ok:false,error:'invalid_request_id'},400);
      if(typeof body.title!=='string'||!body.title.trim()||body.title.trim().length>300)return json({ok:false,error:'invalid_title'},400);
      if(!['daily','weekly','monthly'].includes(body.cadence)||typeof body.time_local!=='string'||!/^([01]\d|2[0-3]):[0-5]\d$/.test(body.time_local))return json({ok:false,error:'invalid_schedule'},400);
      if(body.cadence==='weekly'&&(!Number.isInteger(body.weekday)||body.weekday<1||body.weekday>7))return json({ok:false,error:'invalid_schedule'},400);
      if(body.cadence==='monthly'&&(!Number.isInteger(body.month_day)||body.month_day<1||body.month_day>31))return json({ok:false,error:'invalid_schedule'},400);
      Object.assign(args,{p_title:body.title.trim(),p_cadence:body.cadence,p_time_local:body.time_local,p_weekday:body.cadence==='weekly'?body.weekday:null,p_month_day:body.cadence==='monthly'?body.month_day:null,p_request_id:body.requestId||null});
    }
    const r=await db.rpc('recurring_manage_rule',args);
    if(r.error){const code=String(r.error.message||'');return json({ok:false,error:ERROR_STATUS[code]?code:'recurring_unavailable'},ERROR_STATUS[code]||503);}
    return json(r.data);
  }catch{return json({ok:false,error:'recurring_unavailable'},503);}
});
