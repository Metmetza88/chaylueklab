import { adminDb, CORS, isOwner, json, lineIdentity, requireMember, requirePremium } from "../_shared/membership.ts";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const LINE_USER = /^U[0-9a-f]{32}$/i;
const DEBT_FIELDS = "id,title,counterparty,direction,amount,settled_amount,due_date,status,created_at,updated_at";
const RECURRING_FIELDS = "id,title,cadence,time_local,weekday,month_day,next_due_at,status,error,created_at,updated_at";

export function validMoney(value: unknown): number | null {
  if (typeof value !== "number" && typeof value !== "string") return null;
  const n = Number(value);
  return Number.isFinite(n) && n > 0 && n <= 1e9 && Math.abs(n * 100 - Math.round(n * 100)) < 0.00001 ? n : null;
}

export function validDate(value: unknown): string | null | false {
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value) || value < "1900-01-01" || value > "2100-12-31") return false;
  const at = new Date(value + "T00:00:00Z");
  return Number.isFinite(at.getTime()) && at.toISOString().slice(0, 10) === value ? value : false;
}

function requestId(body: any): string | null | false {
  return body.requestId === undefined || body.requestId === null ? null : UUID.test(String(body.requestId)) ? String(body.requestId) : false;
}

function fail(error: any): Response {
  const message = String(error?.message || "");
  const known: Record<string, number> = { invalid_debt:400, invalid_settlement:400, debt_not_found:404, settlement_exceeds_balance:409, request_conflict:409, debt_limit_reached:409 };
  for (const [code, status] of Object.entries(known)) if (message === code) return json({ok:false,error:code}, status);
  console.error("life-tools request failed", {code:error?.code || "unknown"});
  return json({ok:false,error:"server_error"},500);
}

export async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") return new Response("ok",{headers:CORS});
  if (req.method !== "POST") return json({ok:false,error:"method_not_allowed"},405);
  try {
    let body: any;
    try { body = await req.json(); } catch { return json({ok:false,error:"invalid_json"},400); }
    if (!body || typeof body !== "object" || Array.isArray(body)) return json({ok:false,error:"invalid_json"},400);
    const user = await lineIdentity(body);
    if (!user || !LINE_USER.test(user)) return json({ok:false,error:"invalid_line_login"},401);
    const db = adminDb();
    const suspended = await requireMember(db,user);
    if (suspended) return suspended;
    const own = (q: any) => q.eq("line_user_id",user).eq("target_id",user);

    if (body.action === "admin_list_debts" || body.action === "admin_list_recurring") {
      if (!await isOwner(db,user)) return json({ok:false,error:"owner_required"},403);
      if (body.user && !LINE_USER.test(String(body.user))) return json({ok:false,error:"invalid_user"},400);
      const offset = Number(body.offset || 0);
      if (!Number.isInteger(offset) || offset < 0 || offset > 1000000) return json({ok:false,error:"invalid_offset"},400);
      const debts = body.action === "admin_list_debts";
      let q = db.from(debts ? "life_debts" : "recurring_reminder_rules").select((debts ? DEBT_FIELDS : RECURRING_FIELDS) + ",line_user_id,target_id",{count:"exact"});
      if (body.user) q = q.eq("line_user_id",body.user).eq("target_id",body.user);
      const r = await q.order("created_at",{ascending:false}).range(offset,offset+49);
      if (r.error) throw r.error;
      return json({ok:true,items:r.data || [],count:r.count || 0,offset,pageSize:50});
    }

    if (body.action === "list_debts") {
      const offset = Number(body.offset || 0);
      if (!Number.isInteger(offset) || offset < 0 || offset > 1000000 || (body.status && !["open","settled","all"].includes(body.status))) return json({ok:false,error:"invalid_filter"},400);
      let q = own(db.from("life_debts").select(DEBT_FIELDS,{count:"exact"}));
      if (body.status && body.status !== "all") q = q.eq("status",body.status);
      const r = await q.order("created_at",{ascending:false}).range(offset,offset+99);
      if (r.error) throw r.error;
      const totals = await db.rpc("life_debt_totals",{p_user:user});
      if (totals.error) throw totals.error;
      return json({ok:true,debts:r.data || [],totals:totals.data,count:r.count || 0,offset,pageSize:100});
    }

    if (body.action === "dashboard") {
      const premium = !(await requirePremium(db,user));
      const results = await Promise.all([
        premium ? db.rpc("life_weekly_summary",{p_user:user}) : Promise.resolve({data:null,error:null}),
        own(db.from("life_debts").select(DEBT_FIELDS)).eq("status","open").order("due_date",{ascending:true,nullsFirst:false}).order("created_at",{ascending:false}).limit(100),
        db.rpc("life_debt_totals",{p_user:user}),
        own(db.from("recurring_reminder_rules").select(RECURRING_FIELDS)).order("next_due_at",{ascending:true}).limit(100)
      ]);
      for (const r of results) if (r.error) throw r.error;
      return json({ok:true,premium,weekly:results[0].data,debts:results[1].data || [],debtTotals:results[2].data,recurring:results[3].data || [],debtLimit:await isOwner(db,user) ? null : 100,reportLabel:"สัปดาห์นี้ถึงตอนนี้ · เวลาไทย",settlementNote:"การปิดยอดค้างไม่สร้างรายรับหรือรายจ่ายอัตโนมัติ"});
    }

    if (body.action === "delete_debt") {
      if (!UUID.test(String(body.id))) return json({ok:false,error:"invalid_id"},400);
      const r = await own(db.from("life_debts").delete().eq("id",body.id)).select("id").maybeSingle();
      if (r.error) throw r.error;
      return r.data ? json({ok:true}) : json({ok:false,error:"debt_not_found"},404);
    }

    if (!["create_debt","settle_debt","weekly"].includes(body.action)) return json({ok:false,error:"unknown_action"},400);
    const denied = await requirePremium(db,user);
    if (denied) return denied;
    if (body.action === "weekly") {
      const r = await db.rpc("life_weekly_summary",{p_user:user});
      if (r.error) throw r.error;
      return json({ok:true,weekly:r.data,reportLabel:"สัปดาห์นี้ถึงตอนนี้ · เวลาไทย"});
    }
    const token = requestId(body);
    if (token === false) return json({ok:false,error:"invalid_request_id"},400);
    if (body.action === "create_debt") {
      const title = typeof body.title === "string" ? body.title.trim() : "";
      const counterparty = typeof body.counterparty === "string" ? body.counterparty.trim() : "";
      const amount = validMoney(body.amount), due = validDate(body.due_date);
      if (!title || title.length > 200 || counterparty.length > 100 || !["receivable","payable"].includes(body.direction) || amount === null || due === false) return json({ok:false,error:"invalid_debt"},400);
      const r = await db.rpc("life_debt_create",{p_user:user,p_title:title,p_counterparty:counterparty,p_direction:body.direction,p_amount:amount,p_due_date:due,p_request_id:token});
      if (r.error) throw r.error;
      return json({ok:true,debt:r.data,accountingRecorded:false});
    }
    const amount = validMoney(body.amount);
    if (!UUID.test(String(body.id)) || amount === null) return json({ok:false,error:"invalid_settlement"},400);
    const r = await db.rpc("life_debt_settle",{p_user:user,p_id:body.id,p_amount:amount,p_request_id:token});
    if (r.error) throw r.error;
    return json({ok:true,...r.data,settlementNote:"บันทึกสถานะชำระแล้วเท่านั้น ไม่สร้างรายรับหรือรายจ่ายอัตโนมัติ"});
  } catch (error) { return fail(error); }
}

Deno.serve(handler);
